# FINAL HUNT — South Dakota West River iOS project

This is an early playable mobile hunting-simulator foundation for iPhone, built with Expo / React Native / Three.js. It is **not** a finished AAA hunting simulator and it is not yet a signed IPA.

## What this build contains

- Landscape iPhone layout, menu, career panel, outfitter, property panel and settings.
- Procedural West River-inspired rolling prairie, grass, shelterbelts, creek, pond, road, fence, cabin, blind and food plot.
- Four real wildlife GLB model targets: whitetail buck, doe, fawn and mule deer buck.
- The deer source pack supplies Idle, Walk and Run animation clips. The app loads the model clips and animates wildlife in the scene.
- Herd movement and basic flee response to proximity / calls; changing clear, cloudy, windy, fog, rain and snow presentation.
- Per-buck generated antler phenotype values (spread, mass, left/right tine counts and rack score) and procedural rack variation.
- Mobile hotbar, look drag, aim, fire, call, walk/run, persistent career data, store, trophy log and property upgrades.

## Build on GitHub from an iPhone

1. Create a GitHub account and a new repository.
2. Upload the contents of this project folder (keep the `.github` directory).
3. Open the repository's **Actions** tab.
4. Select **Build FINAL HUNT unsigned IPA** and tap **Run workflow**.
5. When it finishes, open the run and download the `FINAL_HUNT_unsigned_IPA` artifact.
6. Sign the IPA with your preferred iOS signing method.

The workflow runs on GitHub's hosted macOS runner. The model downloader fetches the CC BY 4.0 wildlife models before Expo bundles the app. The whitetail buck has a fallback to Grab3D’s CC0 static deer model if the animated buck source is unavailable. If the doe, fawn or mule deer source paths change or the host blocks the runner, the workflow will fail at the asset-fetch step rather than silently packaging fake models.

## Controls

- Drag the game view to look around.
- Use the left hotbar to select rifle, binoculars, call or track tool.
- Use Aim, Fire, Call, Walk and Run on the right.
- The current movement buttons advance the player in fixed increments; a continuous virtual joystick is a future control-system task.

## Current limitations — not yet implemented

This is a working foundation, not the complete requested simulator. It does not yet include production-grade ballistics, detailed shot placement / blood tracking, true multiplayer, all requested species, waterfowl flight AI, a full weapon catalogue, 50+ calls, full vehicle physics, full property placement, a large streaming world, advanced trophy scoring, or complete animal sound libraries. The present wildlife roster is deer-focused. The harvest log currently records a simplified career event and is not yet a full field-dressing / inspection system.

## Asset credits

Wildlife models by vinish.dev, licensed CC BY 4.0. Required credit: `Models by vinish.dev (https://vinish.dev/free-3d-models/), licensed under CC BY 4.0.` See `ASSET_MANIFEST.md`.
