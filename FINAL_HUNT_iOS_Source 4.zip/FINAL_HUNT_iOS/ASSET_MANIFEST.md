# FINAL HUNT asset manifest

## Wildlife (downloaded automatically during the iOS cloud build)

The app's build workflow fetches four GLB models into `assets/models/` before Expo bundles the app:

- White-Tailed Buck — vinish.dev, CC BY 4.0
- White-Tailed Doe — vinish.dev, CC BY 4.0
- White-Tailed Fawn — vinish.dev, CC BY 4.0
- Mule Deer Buck — vinish.dev, CC BY 4.0

Source collection: https://vinish.dev/free-3d-models/deer-elk-and-moose
Required credit: `Models by vinish.dev (https://vinish.dev/free-3d-models/), licensed under CC BY 4.0.`

The source collection describes these as GLB models with Idle, Walk and Run animation clips. The app uses those clips when present. Individual bucks also receive generated antler phenotype values and a procedurally varied rack in the game scene. The rack values are game-generated, not a scientific genetic simulation.

## Environment

The West River terrain, prairie vegetation, cedar shelterbelts, creek, pond, two-track road, fence, cabin, blind and food plot in this milestone are generated from original Three.js geometry and materials. They are not represented as downloaded photogrammetry assets.

## Important licensing note

The wildlife pack is CC BY 4.0 and requires credit. Keep this manifest and the in-game credits screen with redistributed builds. Re-check the source and license before a commercial release. No third-party asset is claimed to be included locally until the build downloader successfully fetches it.

### Whitetail buck fallback

If the animated vinish.dev buck file is unavailable at build time, the downloader falls back to Grab3D's lightweight White-Tailed Deer GLB (`https://grab3d.com/dl/deer/deer-light.glb`). Grab3D lists this model as CC0 1.0. It is a static pose without a rig, so it does not provide skeletal walk/run animation. The app retains basic root movement for this fallback. Source: https://grab3d.com/models/animals/deer/.
