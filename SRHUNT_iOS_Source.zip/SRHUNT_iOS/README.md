# SR HUNT iOS starter project

This is native SwiftUI + RealityKit source, intended to be opened in Xcode on a Mac. It is not a signed IPA and cannot be installed directly from this ZIP.

## Build an iPhone app
1. On a Mac, install the current Xcode from the Mac App Store.
2. Create a new iOS App project named `SRHUNT`, Interface `SwiftUI`, Language `Swift`.
3. Replace the generated `SRHUNTApp.swift` and `ContentView.swift` with the two files in this folder.
4. Set the deployment target to iOS 17 or later.
5. Add a realistic deer model to the app target's Copy Bundle Resources with the exact resource name `WhitetailBuck.usdz`.
6. Select your iPhone as the run destination, choose your Apple development Team under Signing & Capabilities, then Build and Run.
7. To export an IPA: Product → Archive → Distribute App → Development or Ad Hoc. A valid signing team/profile is required.

## Real deer asset
A high-detail, 745k-triangle whitetail buck with 4K PBR textures is available as a static model under CC0 at:
https://grab3d.com/models/animals/deer/

The model is static and unrigged, so it does not provide walk/run/feeding animations. A production hunting game needs a rigged, animated whitetail asset (idle, walk, trot, run, graze, drink, alert, flee) and optimized LODs. Import/convert the USDZ into the project and name it `WhitetailBuck.usdz`. The app includes a simple procedural fallback deer if the asset is not added.

## Current prototype scope
- RealityKit 3D scene, basic prairie/tree silhouettes and lighting
- Touch movement joystick and mode menu
- Optic zoom UI, call button and settings sheet
- Static high-detail deer asset loading hook

## Not yet production-complete
The terrain is currently a prototype, the deer AI/animation system is not finished, calls are synthesized test audio, and guided hunts/species are menu selections rather than complete missions. Full photorealism requires professionally rigged animal models, terrain/foliage assets, recorded licensed wildlife audio, optimized LODs, animation state machines, and device testing. The source does not claim those features are already complete.
