import SwiftUI

@main
struct SRHUNTApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
