import SwiftUI
import RealityKit
import AVFoundation

struct ContentView: View {
    @State private var mode = "Free Hunt"
    @State private var selectedAnimal = "Whitetail Deer"
    @State private var showMenu = true
    @State private var showSettings = false
    @State private var sensitivity: Double = 1.0
    @State private var quality = "Ultra"
    @State private var wind = "SW 8 mph"
    @State private var audio: AVAudioPlayer?
    @State private var world: Entity?
    @State private var player: Entity?
    @State private var look = CGSize.zero
    @State private var move = CGSize.zero
    @State private var isAiming = false
    @State private var zoom: Double = 4

    var body: some View {
        ZStack {
            RealityView { content in
                let root = Entity()
                buildWorld(into: root)
                content.add(root)
                world = root
                player = root.findEntity(named: "Player")
            } update: { content in
                guard let root = world else { return }
                if let camera = root.findEntity(named: "CameraRig") {
                    camera.position.x += Float(move.width) * 0.0008
                    camera.position.z += Float(move.height) * 0.0008
                    camera.transform.rotation = simd_quatf(angle: Float(look.width) * 0.002, axis: [0,1,0])
                }
            }
            .ignoresSafeArea()

            VStack {
                HStack {
                    VStack(alignment: .leading, spacing: 3) {
                        Text("SR HUNT").font(.system(size: 17, weight: .black, design: .rounded)).tracking(2)
                        Text("SOUTH DAKOTA • FIELD 01").font(.system(size: 9, weight: .bold)).tracking(1.5).foregroundStyle(.white.opacity(0.75))
                    }
                    Spacer()
                    Label("48°F  ·  \(wind)", systemImage: "wind")
                        .font(.system(size: 11, weight: .semibold)).padding(10)
                        .background(.black.opacity(0.48), in: Capsule())
                }
                .padding(.horizontal, 18).padding(.top, 12)
                Spacer()
                if isAiming {
                    VStack(spacing: 4) {
                        Text("\(Int(zoom))× OPTIC").font(.system(size: 10, weight: .black)).tracking(2)
                        Image(systemName: "plus").font(.system(size: 28, weight: .ultraLight))
                    }.padding(14).background(.black.opacity(0.35), in: Circle())
                }
                Spacer()
                HStack(alignment: .bottom) {
                    Joystick { value in move = value }
                    Spacer()
                    VStack(spacing: 10) {
                        control("AIM", icon: "scope") { isAiming.toggle() }
                        control("CALL", icon: "megaphone") { playCall() }
                        control("BINOS", icon: "binoculars") { isAiming = true; zoom = 8 }
                        control("MENU", icon: "line.3.horizontal") { showMenu = true }
                    }
                }.padding(.horizontal, 16).padding(.bottom, 18)
            }
            .foregroundStyle(.white)

            if showMenu {
                menuOverlay
            }
        }
        .preferredColorScheme(.dark)
        .statusBarHidden()
        .sheet(isPresented: $showSettings) { settingsSheet }
    }

    private var menuOverlay: some View {
        ZStack {
            LinearGradient(colors: [.black.opacity(0.92), .black.opacity(0.55), .clear], startPoint: .leading, endPoint: .trailing)
            VStack(alignment: .leading, spacing: 16) {
                Text("SOUTH DAKOTA  /  WILDERNESS SIMULATOR").font(.system(size: 9, weight: .black)).tracking(3).foregroundStyle(Color(red:0.83, green:0.72, blue:0.45))
                Text("SR\nHUNT").font(.system(size: 64, weight: .black, design: .rounded)).lineSpacing(-12)
                Text("A living prairie. A quiet timber edge. The hunt is yours.").font(.system(size: 14)).foregroundStyle(.white.opacity(0.8)).frame(maxWidth: 270, alignment: .leading)
                VStack(alignment: .leading, spacing: 9) {
                    ForEach(["Free Hunt", "Guided Hunt", "Duck Hunt", "Pheasant Hunt", "Turkey Hunt"], id: \.self) { item in
                        Button { mode = item; showMenu = false } label: {
                            HStack { Text(item.uppercased()).tracking(2); Spacer(); Image(systemName: "arrow.up.right") }
                                .font(.system(size: 13, weight: .black)).foregroundStyle(item == mode ? Color(red:0.9,green:0.78,blue:0.5) : .white)
                                .padding(.vertical, 8).frame(maxWidth: 290)
                        }
                    }
                }
                HStack(spacing: 18) {
                    Button("LOADOUT") { showSettings = true }.font(.system(size: 11, weight: .black)).tracking(2)
                    Button("SETTINGS") { showSettings = true }.font(.system(size: 11, weight: .black)).tracking(2)
                }.padding(.top, 8)
                Text("Prototype build • 3D scene and touch controls").font(.system(size: 10)).foregroundStyle(.white.opacity(0.55)).padding(.top, 10)
                Spacer()
            }.padding(.leading, 28).padding(.top, 70).frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        }.ignoresSafeArea()
    }

    private var settingsSheet: some View {
        NavigationStack {
            Form {
                Section("GRAPHICS") {
                    Picker("Quality", selection: $quality) { Text("High").tag("High"); Text("Ultra").tag("Ultra") }
                    Text("Ultra quality requires a compatible iPhone and optimized bundled assets.").font(.caption).foregroundStyle(.secondary)
                }
                Section("OPTICS") {
                    Slider(value: $zoom, in: 1...25, step: 1) { Text("Zoom") }
                    Text("Magnification: \(Int(zoom))×")
                }
                Section("ANIMAL") {
                    Picker("Species", selection: $selectedAnimal) { Text("Whitetail Deer").tag("Whitetail Deer"); Text("Mallard Duck").tag("Mallard Duck"); Text("Ring-necked Pheasant").tag("Ring-necked Pheasant"); Text("Wild Turkey").tag("Wild Turkey") }
                }
            }.navigationTitle("Field Setup").toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Done") { showSettings = false } } }
        }.presentationDetents([.medium, .large])
    }

    private func control(_ title: String, icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 4) { Image(systemName: icon).font(.system(size: 18)); Text(title).font(.system(size: 8, weight: .black)).tracking(1) }
                .frame(width: 58, height: 58).background(.black.opacity(0.55), in: RoundedRectangle(cornerRadius: 17)).overlay(RoundedRectangle(cornerRadius: 17).stroke(.white.opacity(0.28)))
        }
    }

    private func playCall() {
        // A synthesized field-call tone. Replace with licensed recorded animal-call audio in the production asset bundle.
        let sampleRate = 44100.0
        let count = Int(sampleRate * 0.65)
        var samples = [Int16]()
        for i in 0..<count {
            let t = Double(i) / sampleRate
            let envelope = min(1, t * 18) * max(0, 1 - t / 0.65)
            let wave = sin(2 * .pi * (390 - 120 * t) * t) * envelope * 0.22
            samples.append(Int16(wave * Double(Int16.max)))
        }
        let data = Data(bytes: samples, count: samples.count * MemoryLayout<Int16>.size)
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("field-call.wav")
        var wav = Data()
        func append<T: FixedWidthInteger>(_ value: T) { var v = value.littleEndian; withUnsafeBytes(of: &v) { wav.append(contentsOf: $0) } }
        wav.append(contentsOf: Array("RIFF".utf8)); append(UInt32(36 + data.count)); wav.append(contentsOf: Array("WAVEfmt ".utf8)); append(UInt32(16)); append(UInt16(1)); append(UInt16(1)); append(UInt32(44100)); append(UInt32(88200)); append(UInt16(2)); append(UInt16(16)); wav.append(contentsOf: Array("data".utf8)); append(UInt32(data.count)); wav.append(data)
        try? wav.write(to: url)
        audio = try? AVAudioPlayer(contentsOf: url); audio?.play()
    }

    private func buildWorld(into root: Entity) {
        let ground = ModelEntity(mesh: .generatePlane(width: 500, depth: 500), materials: [SimpleMaterial(color: UIColor(red:0.25, green:0.31, blue:0.17, alpha:1), roughness: 1, isMetallic: false)])
        ground.position.y = -0.05; root.addChild(ground)
        let camera = PerspectiveCamera(); camera.name = "CameraRig"; camera.position = [0, 1.72, 5.5]; camera.look(at: [0, 1.35, 0], from: camera.position, relativeTo: nil); root.addChild(camera)
        let sun = DirectionalLight(); sun.light.intensity = 18000; sun.orientation = simd_quatf(angle: -.7, axis: [1,0,0]); root.addChild(sun)
        let ambient = PointLight(); ambient.light.intensity = 1100; ambient.position = [0, 12, 0]; root.addChild(ambient)
        for i in 0..<34 {
            let x = Float((i * 37) % 90) - 45
            let z = Float((i * 19) % 110) - 55
            addTree(to: root, at: [x, 0, z])
        }
        for i in 0..<28 {
            let x = Float((i * 13) % 70) - 35
            let z = Float((i * 29) % 90) - 45
            let grass = ModelEntity(mesh: .generateBox(size: [0.06, Float(0.25 + (i % 4) * 0.08), 0.04]), materials: [SimpleMaterial(color: UIColor(red:0.45, green:0.49, blue:0.25, alpha:1), roughness: 1, isMetallic: false)])
            grass.position = [x, 0.12, z]; root.addChild(grass)
        }
        let animal = Entity(); animal.name = "WhitetailAsset"
        if let deer = try? Entity.load(named: "WhitetailBuck") {
            deer.scale = [1,1,1]; deer.position = [4,0,-18]; animal.addChild(deer)
        } else {
            makeFallbackDeer(in: animal)
            animal.position = [4,0,-18]
        }
        root.addChild(animal)
        // Distant terrain silhouettes create depth until a full terrain heightmap is added.
        for i in 0..<9 {
            let hill = ModelEntity(mesh: .generateSphere(radius: 1), materials: [SimpleMaterial(color: UIColor(red:0.31, green:0.36, blue:0.22, alpha:1), roughness: 1, isMetallic: false)])
            hill.scale = [Float(8 + i % 3 * 4), 2.5, 6]
            hill.position = [Float(i * 13 - 50), -1.8, -75 - Float(i % 3) * 9]
            root.addChild(hill)
        }
    }

    private func addTree(to root: Entity, at p: SIMD3<Float>) {
        let trunk = ModelEntity(mesh: .generateCylinder(height: 5.5, radius: 0.22), materials: [SimpleMaterial(color: UIColor(red:0.22, green:0.14, blue:0.08, alpha:1), roughness: 1, isMetallic: false)])
        trunk.position = p + [0, 2.7, 0]; root.addChild(trunk)
        for j in 0..<3 {
            let crown = ModelEntity(mesh: .generateSphere(radius: 2.0 - Float(j) * 0.25), materials: [SimpleMaterial(color: UIColor(red:0.12, green:0.22 + CGFloat(j) * 0.025, blue:0.12, alpha:1), roughness: 1, isMetallic: false)])
            crown.scale = [1.1, 0.9, 1.0]; crown.position = p + [0, 4.1 + Float(j) * 1.15, 0]; root.addChild(crown)
        }
    }

    private func makeFallbackDeer(in root: Entity) {
        let coat = UIColor(red:0.42, green:0.25, blue:0.13, alpha:1)
        func part(_ mesh: MeshResource, _ color: UIColor, _ position: SIMD3<Float>, _ scale: SIMD3<Float>) {
            let e = ModelEntity(mesh: mesh, materials: [SimpleMaterial(color: color, roughness: 0.9, isMetallic: false)])
            e.position = position; e.scale = scale; root.addChild(e)
        }
        part(.generateSphere(radius: 0.55), coat, [0,1.25,0], [1.6,0.85,0.65])
        part(.generateSphere(radius: 0.32), coat, [0.65,1.85,-0.02], [0.65,1.2,0.55])
        part(.generateSphere(radius: 0.2), coat, [0.92,2.35,0], [0.8,0.65,0.65])
        for x: Float in [-0.48,0.48] { for z: Float in [-0.22,0.22] { part(.generateCylinder(height: 0.95, radius: 0.055), coat, [x,0.55,z], [1,1,1]) } }
        let antler = UIColor(red:0.78, green:0.69, blue:0.48, alpha:1)
        for side in [-1.0,1.0] {
            part(.generateCylinder(height: 0.65, radius: 0.035), antler, [0.8,2.78,Float(side)*0.2], [1,1,1])
            for tine in 0..<3 { part(.generateCylinder(height: 0.28, radius: 0.022), antler, [0.8,2.98,Float(side) * (0.2 + Float(tine)*0.12)], [1,1,1]) }
        }
    }
}

struct Joystick: View {
    var onChange: (CGSize) -> Void
    @State private var offset = CGSize.zero
    var body: some View {
        ZStack {
            Circle().fill(.black.opacity(0.35)).overlay(Circle().stroke(.white.opacity(0.45), lineWidth: 2)).frame(width: 112, height: 112)
            Circle().fill(Color(red:0.78, green:0.7, blue:0.49).opacity(0.9)).overlay(Circle().stroke(.white.opacity(0.6))).frame(width: 44, height: 44).offset(offset)
        }
        .contentShape(Circle())
        .gesture(DragGesture(minimumDistance: 0).onChanged { v in
            let x = max(-34, min(34, v.translation.width)); let y = max(-34, min(34, v.translation.height))
            offset = CGSize(width:x,height:y); onChange(offset)
        }.onEnded { _ in withAnimation(.spring(response:0.22,dampingFraction:0.65)) { offset = .zero }; onChange(.zero) })
        .accessibilityLabel("Movement joystick")
    }
}
